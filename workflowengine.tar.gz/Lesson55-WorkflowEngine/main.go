package main

// The following are the core capabilities required in the workflow system
// 1.

func main() {

}
